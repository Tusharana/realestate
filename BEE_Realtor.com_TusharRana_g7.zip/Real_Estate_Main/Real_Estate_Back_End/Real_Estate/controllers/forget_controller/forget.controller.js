const PasswordReset = require('../../models/forget/forget.mongo.js');
function forget(req,res){

}

module.exports = forget;